G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3-10.0.3~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-06-17T20:57:12+02:00*
G04 #@! TF.ProjectId,unicorn,756e6963-6f72-46e2-9e6b-696361645f70,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3-10.0.3~ubuntu24.04.1) date 2026-06-17 20:57:12*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.800000X1.800000*%
%ADD11C,1.800000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D1*
X170180000Y-90932000D03*
D11*
X167640000Y-90932000D03*
G04 #@! TD*
M02*
